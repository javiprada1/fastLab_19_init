# FastLab: Init
[CITE HUB] Our fast Lab to test ours capacities and habilities how web developers.


# Challenge

The main objective of this first FastLab is that we learn a way to work collaboratively with defined objectives.

We will also validate through extreme programming the knowledge about the Client / Server model.

## Installation

Use the Command Palette to execute Git:Clone.

Add this url: https://github.com/javiprada1/fastLab_19_init.git to clone this project in your local.

Deploy in MySQL the DB locate in /databases.

Enjoy development.


## Requirements

- XAMPP (MySQL, Apache y PHP)
- Visual Studio Code
- Git


## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)
